package stepDefination;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class elearningSteps {
	WebDriver driver;
	@Given("To launch elearning website")
	public void to_launch_elearning_website() {
	    // Write code here that turns the phrase above into concrete actions
		System.setProperty("webdriver.chrome.driver","C:\\Users\\BABITAFERNANDEZ\\Downloads\\chromedriver_win32 (1)\\chromedriver.exe");
		driver = new ChromeDriver();
    	
        driver.get ("http://elearningm1.upskills.in/index.php");
	}

	@When("signup btn is visible")
	public void signup_btn_is_visible() {
	    // Write code here that turns the phrase above into concrete actions
		System.out.println(driver.findElement(By.linkText("Sign up!")).isDisplayed());
	}

	@Then("click signUp btn")
	public void click_signUp_btn() {
	    // Write code here that turns the phrase above into concrete actions
		driver.findElement(By.linkText("Sign up!")).click();
	}

	@Then("fill up the Registration form for all mandatory fields")
	public void fill_up_the_Registration_form_for_all_mandatory_fields() {
	    // Write code here that turns the phrase above into concrete actions
		String userName="Babita";
		LocalDateTime currentDateTime = LocalDateTime.now();
		DateTimeFormatter dtf= DateTimeFormatter.ofPattern("ddMMyyhhmmss");
		String formattedDateTime= currentDateTime.format(dtf);
		userName=userName.concat(formattedDateTime);
		driver.findElement(By.name("firstname")).sendKeys("Babita");
		driver.findElement(By.name("lastname")).sendKeys("Rout");
		driver.findElement(By.name("email")).sendKeys("babita5@gmail.com");
		driver.findElement(By.name("username")).sendKeys(userName);
		driver.findElement(By.name("pass1")).sendKeys("babita123");
		driver.findElement(By.name("pass2")).sendKeys("babita123");
		
	}

	@Then("click on register btn")
	public void click_on_register_btn() {
	    // Write code here that turns the phrase above into concrete actions
		driver.findElement(By.name("submit")).click();
	}

	@Then("Verify Message {string}")
	public void verify_Message(String string) throws InterruptedException {
	    // Write code here that turns the phrase above into concrete actions
	 //  driver.findElement(By.cssSelector("An email has been sent to help you remember your login and password."));
	String Actual=driver.getPageSource();
	System.out.println(Actual);
		String Expected="Your personal settings have been registered.";
		driver.getPageSource().contains("Your personal settings have been registered.");
		if(Actual.contains(Expected))
		{
			System.out.println("Your personal settings have been registered.");
		}
		Assert.assertTrue("User registered Successfully", Actual.contains(Expected));
		Thread.sleep(4000);
	}

	@Then("Click on Next")
	public void click_on_Next() {
	    // Write code here that turns the phrase above into concrete actions
		driver.findElement(By.name("next")).click();
	}

	@Then("on HomePage , click your username")
	public void on_HomePage_click_your_username() {
	    // Write code here that turns the phrase above into concrete actions
		//a[contains(text(),'Homepage')]
		driver.findElement(By.xpath("//a[contains(@class,'dropdown-toggle')]")).click();
	}

	@Then("Choose profile from Dropdown and scroll down")
	public void choose_profile_from_Dropdown_and_scroll_down() {
	    // Write code here that turns the phrase above into concrete actions
		driver.findElement(By.xpath("//ul[contains(@class,'dropdown-menu')]//a[contains(text(),'Profile')]")).click();


	}

	@Then("Click on Messages icon in the left")
	public void click_on_Messages_icon_in_the_left() {
	    // Write code here that turns the phrase above into concrete actions
		driver.findElement(By.xpath("//body/div[@id='page-wrap']/div[@id='top_main_content']/div[1]/div[1]/div[1]/div[1]/div[2]/div[1]/div[1]/div[2]/div[1]/ul[1]/li[2]/a[1]")).click();
		driver.findElement(By.xpath("//a[@href='http://elearningm1.upskills.in/main/messages/inbox.php?f=social']")).click();
	}

	@Then("Click on Compose message icon on the top")
	public void click_on_Compose_message_icon_on_the_top() {
	    // Write code here that turns the phrase above into concrete actions
		driver.findElement(By.xpath("//*[@title='Compose message']")).click();
	}

	@Then("Enter the details shown on the page")
	public void enter_the_details_shown_on_the_page() {
	    // Write code here that turns the phrase above into concrete actions
		WebElement sendTo= driver.findElement(By.xpath("//*[@class='select2-search__field' and @type='search']"));
		WebElement subject= driver.findElement(By.xpath("//*[@name='title']"));
		//	driver.switchTo().frame(1);
	//	driver.findElement(By.xpath(""))
		sendTo.sendKeys("rout.sanjibkumar@gmail.com");
		subject.sendKeys("Test Mail");
		//message.click();
//	message.sendKeys("Hello!!!! Test message.....");
	}

	@Then("Click on Send message")
	public void click_on_Send_message() {
	    // Write code here that turns the phrase above into concrete actions
		driver.findElement(By.name("compose")).click();
		String msg="There was an error while trying to send the message.";
		WebElement actual=driver.findElement(By.xpath("//*[@class='alert alert-danger']"));
		
		System.out.println(actual.getText());
		Assert.assertTrue("Message Sent", actual.getText().equalsIgnoreCase(msg));
	}



}
