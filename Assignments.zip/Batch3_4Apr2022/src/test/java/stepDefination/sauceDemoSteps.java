package stepDefination;

import java.util.Map;


import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import junit.framework.Assert;

public class sauceDemoSteps {
	
	    WebDriver driver;
		@Given("user is on saucedemo homepage")
		public void user_is_on_saucedemo_homepage() {
		    // Write code here that turns the phrase above into concrete actions
			System.setProperty("webdriver.chrome.driver","C:\\Users\\BABITAFERNANDEZ\\Downloads\\chromedriver_win32 (1)\\chromedriver.exe");
			driver = new ChromeDriver();
	    	
	        driver.get ("https://www.saucedemo.com");
	        driver.manage().window().maximize();
		}

		@Given("user logged in using correct credential")
		public void user_logged_in_using_correct_credential(io.cucumber.datatable.DataTable dataTable) {
		    // Write code here that turns the phrase above into concrete actions
		    // For automatic transformation, change DataTable to one of
		    // E, List<E>, List<List<E>>, List<Map<K,V>>, Map<K,V> or
		    // Map<K, List<V>>. E,K,V must be a String, Integer, Float,
		    // Double, Byte, Short, Long, BigInteger or BigDecimal.
		    //
		    // For other transformations you can register a DataTableType.
		   Map<String,String> data=dataTable.asMap(String.class, String.class);
		   driver.findElement(By.name("user-name")).sendKeys(data.get("username"));
		   driver.findElement(By.name("password")).sendKeys(data.get("password"));
		   driver.findElement(By.id("login-button")).click();
		  
		   System.out.println("*********User login is successful************");
		   
		    //Verify the Title page after Login Swag Labs
		  // System.out.println(driver.getTitle());
		   Assert.assertEquals("Swag Labs", driver.getTitle());
		   System.out.println("Title page is validated");
			
				}

		

		@Given("user adds required item to cart")
		public void user_adds_required_item_to_cart() {
		    // Write code here that turns the phrase above into concrete actions
			driver.findElement(By.xpath("//button[@id='add-to-cart-sauce-labs-backpack']")).click();
		//	driver.findElement(By.xpath("//button[@id='add-to-cart-sauce-labs-bike-light']")).click();
			System.out.println("items are being added to the shopping Cart successfully");
		}

		@Given("user proceeds to checkout")
		public void user_proceeds_to_checkout() {
		    // User click on the shopping cart
			driver.findElement(By.xpath("//a[@class='shopping_cart_link']")).click();
			//Validate Checkout page DESCRIPTION etc.. 
			//Click on checkout button
			driver.findElement(By.xpath("//button[@id='checkout']")).click();
			
			
			
		}

		@Given("user enters the following details for checkout")
		public void user_enters_the_following_details_for_checkout(io.cucumber.datatable.DataTable dataTable) throws InterruptedException {
		    // Write code here that turns the phrase above into concrete actions
		    // For automatic transformation, change DataTable to one of
		    // E, List<E>, List<List<E>>, List<Map<K,V>>, Map<K,V> or
		    // Map<K, List<V>>. E,K,V must be a String, Integer, Float,
		    // Double, Byte, Short, Long, BigInteger or BigDecimal.
		    //
		    // For other transformations you can register a DataTableType.
			Map<String,String> data=dataTable.asMap(String.class, String.class);
			   driver.findElement(By.xpath("//input[@id='first-name']")).sendKeys(data.get("FirstName"));
			   driver.findElement(By.xpath("//input[@id='last-name']")).sendKeys(data.get("LastName"));
			   driver.findElement(By.xpath("//input[@id='postal-code']")).sendKeys(data.get("PostalCode"));
			   Thread.sleep(3000);
			   driver.findElement(By.xpath("//input[@id='continue']")).click();
		}

		@When("user confirm checkout")
		public void user_confirm_checkout() {
		    // Write code here that turns the phrase above into concrete actions
			driver.findElement(By.xpath("//button[@id='finish']")).click();
			
		}

		@Then("user verify final confirmation message")
		public void user_verify_final_confirmation_messagge() throws InterruptedException {
		    // Write code here that turns the phrase above into concrete actions
			String Actual=driver.getPageSource().toString();
		//	System.out.println(Actual);
				String Expected="Checkout: Complete!";
			//	driver.getPageSource().contains("CHECKOUT: COMPLETE!");
				if(Actual.contains(Expected))
				{
					System.out.println("CHECKOUT: COMPLETE!");
				}
				Assert.assertTrue("THANK YOU FOR YOUR ORDER", Actual.contains(Expected));
				Thread.sleep(4000);
				System.out.println("Checkout confirmation messagge is received & validated");
				//User click on BACK HOME
				driver.findElement(By.xpath("//button[@id='back-to-products']")).click();
				Thread.sleep(4000);
				//Logout
				driver.findElement(By.xpath("//button[@id='react-burger-menu-btn']")).click();
				Thread.sleep(2000);
				driver.findElement(By.xpath("//a[@id='logout_sidebar_link']")).click();
				
				
				
		}

		@Given("user adds one item and then remove that item to go back")
		public void user_adds_one_item_and_then_remove_that_item_to_go_back() {
		    // Write code here that turns the phrase above into concrete actions
			driver.findElement(By.xpath("//button[@id='add-to-cart-sauce-labs-backpack']")).click();
			driver.findElement(By.xpath("//button[@id='add-to-cart-sauce-labs-bike-light']")).click();
			System.out.println("items are being added to the shopping Cart successfully");		
		  // User click on the shopping cart
			driver.findElement(By.xpath("//a[@class='shopping_cart_link']")).click();
		//Remove one item from cart
			driver.findElement(By.xpath("//button[@id='remove-sauce-labs-backpack']")).click();
			System.out.println("Scenario 2: one item is removed from the cart");
		// click on continue Shopping				
			driver.findElement(By.xpath("//button[@id='continue-shopping']")).click();	
			
		}
		/*@Then("user verify final confirmation message")
		public void user_verify_final_confirmation_message() {
		    // Write code here that turns the phrase above into concrete actions
		    throw new cucumber.api.PendingException();
		}*/

		@Given("user sorts item low to high")
		public void user_sorts_item_low_to_high() throws InterruptedException {
		    // Write code here that turns the phrase above into concrete actions
			/*Thread.sleep(2000);
			driver.findElement(By.xpath("//span[contains(text(),'Name (A to Z)')]")).click();*/
			Select dropdown=new Select(driver.findElement(By.xpath("//*[@class='product_sort_container']")));
			Thread.sleep(2000);
			dropdown.selectByVisibleText("Price (low to high)");
			System.out.println("Scenario 3: items are sorted from low to high order");
			Thread.sleep(4000);
			/*driver.findElement(By.xpath("//option[contains(text(),'Price (low to high)')]")).click();
			Thread.sleep(4000);*/
			
		}



}
