package testRunner;

import cucumber.api.CucumberOptions;
import cucumber.api.junit.Cucumber;
import org.junit.runner.RunWith;

@RunWith(Cucumber.class)
@CucumberOptions(features = "src/test/java/features/Assignment-01.feature",

glue = { "stepDefination"} , plugin={"pretty","html:target/cucumber-reports/report.html"},monochrome=true,
//tags = {"@Sanity"} // Executing single tags
//tags = {"@Babita","@Regression"} // And condition
//tags = {"@Babita,@Regression"}//OR condition
//tags ={"@Functional"}//Executing Feature file
tags ={"@scenario1,@scenario2,@scenario3"}

)
public class TestRunner {

}
